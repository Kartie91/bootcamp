# PK Phonics Academy

A complete platform for phonics education with login, multiple user roles, lessons, flashcards, spelling practice, quizzes, and progress tracking.

## Features

- **Authentication**: Login system with role-based access (Admin, Teacher, Student)
- **Lessons**: Phonics lessons with letter sounds and example words
- **Flashcards**: Interactive flashcard system for each lesson
- **Spelling Practice**: Spelling challenges with difficulty levels
- **Quizzes**: Assessments with instant scoring
- **Progress Tracking**: Student progress and analytics
- **Admin Dashboard**: System stats and user management
- **Web UI**: Interactive HTML frontend with real-time API integration

## Setup

### Install Dependencies

```bash
python -m venv .venv
.venv\Scripts\activate    # Windows
pip install -r requirements.txt
```

### Run the Server

```bash
uvicorn app:app --reload --host 0.0.0.0 --port 8005
```

Server runs at: `http://localhost:8005`

### Test Credentials

- **Admin**: `admin` / `admin123`
- **Teacher**: `teacher` / `teacher123`
- **Student**: `student` / `student123`

## Access the Application

1. Open browser: `http://localhost:8005`
2. Login with any credential above
3. Explore lessons, flashcards, spelling, quizzes, and progress

## API Endpoints

### Authentication

- `POST /auth/login` - Login user
- `POST /auth/logout` - Logout user
- `POST /auth/register` - Register new user (admin only for teachers)

### Lessons

- `GET /lessons` - List all lessons
- `GET /lessons/{id}` - Get specific lesson
- `POST /lessons` - Create lesson (teacher/admin only)

### Flashcards

- `GET /lessons/{id}/flashcards` - List flashcards
- `POST /lessons/{id}/flashcards` - Create flashcard (teacher/admin only)

### Spelling

- `GET /lessons/{id}/spelling` - List spelling challenges
- `POST /lessons/{id}/spelling/check` - Check spelling answer

### Quiz

- `GET /lessons/{id}/quiz` - Get quiz
- `POST /lessons/{id}/quiz/submit` - Submit quiz answers

### Progress

- `GET /progress/my-progress` - Get student's progress
- `GET /progress/student/{id}` - Get any student's progress (teacher/admin)

### Admin

- `GET /admin/users` - List all users (admin only)
- `GET /admin/stats` - Get system statistics (admin only)

## Run Tests

```bash
python -m pytest -q
```

## Docker

```bash
docker build -t pk-phonics-academy .
docker run --rm -p 8005:8005 pk-phonics-academy
```

## Files

- `app.py` - FastAPI main application + API endpoints
- `models.py` - Data models (User, Lesson, Quiz, etc.)
- `database.py` - In-memory database with sample data
- `static/index.html` - Web UI frontend
- `requirements.txt` - Python dependencies
- `Dockerfile` - Docker configuration
- `test_app.py` - API tests
