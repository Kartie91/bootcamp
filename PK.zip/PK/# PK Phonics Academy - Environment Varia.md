# PK Phonics Academy - Environment Variables

SITE_NAME=PK Phonics Academy
SITE_URL=https://pkphonicsacademy.com
CONTACT_EMAIL=pkphonicscademy@email.com