"""Data models and storage for PK Phonics Academy."""

from pydantic import BaseModel
from typing import Optional, List
from enum import Enum
from datetime import datetime


class UserRole(str, Enum):
    ADMIN = "admin"
    TEACHER = "teacher"
    STUDENT = "student"


class User(BaseModel):
    id: str
    username: str
    password: str  # hashed in production
    email: str
    role: UserRole
    created_at: datetime = None

    def __init__(self, **data):
        super().__init__(**data)
        if self.created_at is None:
            self.created_at = datetime.now()


class LoginRequest(BaseModel):
    username: str
    password: str


class AuthResponse(BaseModel):
    token: str
    user_id: str
    username: str
    role: UserRole


class Lesson(BaseModel):
    id: str
    title: str
    description: str
    letter: str
    phonetic_sound: str
    example_words: List[str]
    image_url: Optional[str] = None
    audio_url: Optional[str] = None
    created_by: str  # teacher id


class Flashcard(BaseModel):
    id: str
    lesson_id: str
    word: str
    image_url: Optional[str] = None
    pronunciation: str


class SpellingChallenge(BaseModel):
    id: str
    lesson_id: str
    word: str
    hint: str
    difficulty: str  # easy, medium, hard


class Quiz(BaseModel):
    id: str
    lesson_id: str
    questions: List[dict]
    passing_score: int = 70


class StudentProgress(BaseModel):
    id: str
    student_id: str
    lesson_id: str
    flashcards_completed: int = 0
    spelling_score: Optional[int] = None
    quiz_score: Optional[int] = None
    completed_at: Optional[datetime] = None
