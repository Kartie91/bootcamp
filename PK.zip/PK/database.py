"""In-memory database for PK Phonics Academy."""

from models import User, Lesson, Flashcard, SpellingChallenge, Quiz, StudentProgress, UserRole
from typing import Dict, List, Optional
import uuid
from datetime import datetime

# In-memory storage
users_db: Dict[str, User] = {}
lessons_db: Dict[str, Lesson] = {}
flashcards_db: Dict[str, Flashcard] = {}
spelling_challenges_db: Dict[str, SpellingChallenge] = {}
quizzes_db: Dict[str, Quiz] = {}
progress_db: Dict[str, StudentProgress] = {}
sessions: Dict[str, str] = {}  # token -> user_id


def init_db():
    """Initialize with sample data for all A-Z letters."""
    # Create admin user
    admin = User(
        id="admin1",
        username="admin",
        password="admin123",
        email="admin@pkphonics.com",
        role=UserRole.ADMIN,
    )
    users_db["admin1"] = admin

    # Create teacher
    teacher = User(
        id="teacher1",
        username="teacher",
        password="teacher123",
        email="teacher@pkphonics.com",
        role=UserRole.TEACHER,
    )
    users_db["teacher1"] = teacher

    # Create student
    student = User(
        id="student1",
        username="student",
        password="student123",
        email="student@pkphonics.com",
        role=UserRole.STUDENT,
    )
    users_db["student1"] = student

    # Alphabet data: (letter, phonetic, example_words, image_url)
    alphabet_data = [
        ("A", "/æ/", ["Apple", "Ant", "Astronaut", "Aardvark"], "🍎"),
        ("B", "/b/", ["Ball", "Bat", "Bear", "Butterfly"], "🎾"),
        ("C", "/k/", ["Cat", "Car", "Cup", "Candle"], "🐱"),
        ("D", "/d/", ["Dog", "Doll", "Duck", "Dinosaur"], "🐕"),
        ("E", "/ɛ/", ["Elephant", "Egg", "Eye", "Escalator"], "🐘"),
        ("F", "/f/", ["Fish", "Fox", "Flower", "Fence"], "🐟"),
        ("G", "/g/", ["Goat", "Green", "Grapes", "Guitar"], "🐐"),
        ("H", "/h/", ["House", "Hat", "Hand", "Helicopter"], "🏠"),
        ("I", "/ɪ/", ["Ice", "Igloo", "Ink", "Iron"], "🧊"),
        ("J", "/dʒ/", ["Jellyfish", "Jar", "Jelly", "Jet"], "🪼"),
        ("K", "/k/", ["Kite", "King", "Kitten", "Kangaroo"], "🪁"),
        ("L", "/l/", ["Lion", "Lamp", "Leaf", "Lemon"], "🦁"),
        ("M", "/m/", ["Monkey", "Moon", "Milk", "Muffin"], "🐵"),
        ("N", "/n/", ["Nest", "Nose", "Net", "Noodle"], "🪺"),
        ("O", "/ɔ/", ["Orange", "Octopus", "Olive", "Owl"], "🍊"),
        ("P", "/p/", ["Pig", "Pen", "Penguin", "Pizza"], "🐷"),
        ("Q", "/kw/", ["Queen", "Quilt", "Quest", "Question"], "👑"),
        ("R", "/r/", ["Rabbit", "Rain", "Rainbow", "Robot"], "🐰"),
        ("S", "/s/", ["Sun", "Sea", "Star", "Snake"], "☀️"),
        ("T", "/t/", ["Tiger", "Tree", "Turtle", "Tooth"], "🐯"),
        ("U", "/ʌ/", ["Umbrella", "Upstairs", "Universe", "Umpire"], "☂️"),
        ("V", "/v/", ["Violin", "Van", "Volcano", "Vegetable"], "🎻"),
        ("W", "/w/", ["Water", "Whale", "Watermelon", "Witch"], "🐋"),
        ("X", "/ks/", ["Xylophone", "Xray", "X-mark"], "🎹"),
        ("Y", "/j/", ["Yo-yo", "Yarn", "Yellow", "Yawn"], "🤃"),
        ("Z", "/z/", ["Zebra", "Zero", "Zoo", "Zipper"], "🦓"),
    ]

    # Create lessons for all letters
    for letter, sound, words, emoji in alphabet_data:
        lesson_id = f"lesson_{letter.lower()}"
        lesson = Lesson(
            id=lesson_id,
            title=f"Letter {letter}",
            description=f"Learn the letter {letter} and its sound {sound}",
            letter=letter,
            phonetic_sound=sound,
            example_words=words,
            image_url=emoji,  # Using emoji as image
            created_by="teacher1",
        )
        lessons_db[lesson_id] = lesson

        # Create flashcards for each lesson (first 2 words)
        for idx, word in enumerate(words[:2]):
            fc_id = f"fc_{letter.lower()}_{idx+1}"
            flashcard = Flashcard(
                id=fc_id,
                lesson_id=lesson_id,
                word=word,
                pronunciation=word.upper(),
            )
            flashcards_db[fc_id] = flashcard

        # Create spelling challenge
        sc_id = f"sc_{letter.lower()}"
        spelling = SpellingChallenge(
            id=sc_id,
            lesson_id=lesson_id,
            word=words[0],
            hint=f"Starts with {letter}",
            difficulty="easy",
        )
        spelling_challenges_db[sc_id] = spelling

        # Create quiz for each lesson
        quiz_id = f"quiz_{letter.lower()}"
        quiz = Quiz(
            id=quiz_id,
            lesson_id=lesson_id,
            questions=[
                {
                    "question": f"What is the first letter?",
                    "options": [letter, chr(ord(letter) - 1) if ord(letter) > 65 else "Z", chr(ord(letter) + 1) if ord(letter) < 90 else "A"],
                    "answer": letter,
                },
                {
                    "question": f"Which word starts with {letter}?",
                    "options": words[:3],
                    "answer": words[0],
                },
            ],
        )
        quizzes_db[quiz_id] = quiz



def add_user(username: str, password: str, email: str, role: UserRole) -> User:
    user_id = str(uuid.uuid4())
    user = User(
        id=user_id, username=username, password=password, email=email, role=role
    )
    users_db[user_id] = user
    return user


def get_user_by_username(username: str) -> Optional[User]:
    for user in users_db.values():
        if user.username == username:
            return user
    return None


def create_session(user_id: str) -> str:
    token = str(uuid.uuid4())
    sessions[token] = user_id
    return token


def get_user_from_token(token: str) -> Optional[User]:
    user_id = sessions.get(token)
    if user_id:
        return users_db.get(user_id)
    return None


def logout_session(token: str):
    if token in sessions:
        del sessions[token]


# Initialize DB on import
init_db()
